<?php
session_start();
include "db_conn.php";

// Check if user is logged in
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

// Handle logout
if (isset($_POST['logout'])) {
  session_destroy();
  header("Location: login.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product Inventory Management</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Custom CSS -->
  <style>
    body {
      padding-top: 56px; /* Adjust body padding to accommodate the fixed navbar */
    }
    #sidebar {
      position: fixed;
      top: 0;
      left: -250px; /* Initially hidden */
      height: 100%;
      width: 250px;
      z-index: 1;
      background-color: #333;
      padding-top: 3.5rem; /* Adjust padding to accommodate the fixed navbar */
      transition: all 0.3s ease;
    }
    #sidebar.active {
      left: 0; /* Displayed */
    }
    #sidebar ul.components {
      padding: 20px 0;
    }
    #sidebar ul li {
      padding: 10px 15px;
      font-size: 1.1em;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    #sidebar ul li a {
      color: #fff;
    }
    #sidebar ul li a:hover {
      background-color: #555;
    }
    #sidebar .navbar-brand {
      padding: 0 15px;
      font-size: 1.5em;
      color: #fff;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    #sidebar .collapse.show {
      position: fixed;
    }
    #sidebar .collapse.show ~ .content {
      margin-left: 250px; /* Adjust content margin to accommodate expanded sidebar */
    }
    .content {
      transition: all 0.3s ease;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <nav id="sidebar">
    <div class="navbar-brand">
      Product Inventory
    </div>
    <ul class="list-unstyled components">
      <li>
        <a href="index.php">Home</a>
      </li>
      <!-- Add any additional sidebar links here -->
    </ul>
  </nav>

  <!-- Page Content -->
  <div class="content">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
      <div class="container-fluid">
        <button type="button" id="sidebarCollapse" class="btn btn-info">
          <i class="fas fa-align-left"></i>
        </button>
        <span class="navbar-brand mb-0 h1 ms-3">PHP Complete CRUD Application</span>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" href="add_new.php">Add New Product</a>
            </li>
          </ul>
          <form class="d-flex" method="post">
            <button class="btn btn-danger" type="submit" name="logout">Logout</button>
          </form>
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
      <?php
      if (isset($_GET["msg"])) {
        $msg = $_GET["msg"];
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        ' . $msg . '
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
      }
      ?>
      <table class="table table-hover text-center">
        <thead class="table-dark">
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Product Name</th>
            <th scope="col">Price</th>
            <th scope="col">Quantity</th>
            <th scope="col">Supplier</th>
            <th scope="col">Description</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $sql = "SELECT * FROM `products`";
          $result = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_assoc($result)) {
          ?>
            <tr>
              <td><?php echo $row["id"] ?></td>
              <td><?php echo $row["product_name"] ?></td>
              <td><?php echo $row["price"] ?></td>
              <td><?php echo $row["quantity"] ?></td>
              <td><?php echo $row["supplier"] ?></td>
              <td><?php echo $row["description"] ?></td>
              <td>
                <a href="edit.php?id=<?php echo $row["id"] ?>" class="link-dark"><i class="fa-solid fa-pen-to-square fs-5 me-3"></i></a>
                <a href="delete.php?id=<?php echo $row["id"] ?>" class="link-dark"><i class="fa-solid fa-trash fs-5"></i></a>
              </td>
            </tr>
          <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Font Awesome -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
  <!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
      $("#sidebarCollapse").on("click", function () {
        $("#sidebar").toggleClass("active");
        // Adjust content margin when sidebar is expanded or collapsed
        $(".content").toggleClass("active");
        // Store the sidebar state in local storage
        localStorage.setItem("sidebar_collapsed", $("#sidebar").hasClass("active"));
      });
      // Check the sidebar state from local storage and adjust accordingly
      if (localStorage.getItem("sidebar_collapsed") === "true") {
        $("#sidebar").addClass("active");
        $(".content").addClass("active");
      }
    });
  </script>
</body>
</html>
