<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form | Product Inventory Management</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <style>
    body {
      background-color: #f8f9fa;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    .wrapper {
      width: 100%;
      max-width: 400px;
      padding: 40px;
      background-color: #fff;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      text-align: center;
    }

    .wrapper h1 {
      margin-bottom: 20px;
      color: #333;
    }

    .input-box {
      position: relative;
      margin-bottom: 20px;
    }

    .input-box input {
      width: calc(100% - 40px);
      padding: 10px;
      padding-left: 40px;
      border: 1px solid #ced4da;
      border-radius: 25px;
      font-size: 16px;
      outline: none;
    }

    .input-box input:focus {
      border-color: #007bff;
    }

    .input-box .bx {
      position: absolute;
      top: 50%;
      left: 15px;
      transform: translateY(-50%);
      color: #ccc;
      font-size: 18px;
    }

    .remember-forgot {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      font-size: 14px;
    }

    .btn-primary {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 25px;
      background-color: #007bff;
      color: #fff;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
      background-color: #0056b3;
    }

    .register-link {
      margin-top: 16px;
      font-size: 14px;
    }

    .register-link a {
      color: #007bff;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .register-link a:hover {
      color: #0056b3;
    }

    .alert-danger {
      background-color: #f8d7da;
      color: #721c24;
      padding: 10px;
      border-radius: 5px;
      margin-bottom: 20px;
    }
  </style>
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
  <div class="wrapper">
    <h1>Login</h1>
    <?php if (isset($error)) { echo '<div class="alert alert-danger">'.$error.'</div>'; } ?>
    <form action="" method="post">
      <div class="input-box">
        <i class='bx bxs-user'></i>
        <input type="text" name="username" placeholder="Username" required>
      </div>
      <div class="input-box">
        <i class='bx bxs-lock-alt'></i>
        <input type="password" name="password" placeholder="Password" required>
      </div>
      <button type="submit" name="login" class="btn btn-primary">Login</button>
      <div class="remember-forgot">
        <label><input type="checkbox">Remember Me</label>
        <a href="#">Forgot Password</a>
      </div>
      <div class="register-link">
        <p>Don't have an account? <a href="#">Register</a></p>
      </div>
    </form>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
